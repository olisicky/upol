## Poznámky
**Obrázek**
* když dávám nějaký objekt do kruhu například, tak to mám zatím funkční s `position: absolute`. To mi ale dělá problémy, když pak upravuji velikost okna, ve kterém vytvářím. V tomto případě my zůstane koule velká a překryje text. Musím to nějak přepnout na `relative`, tam mám ale nějak debilně posunutý obrázek

**Vývojář**
* je to fakt super kontrolovat přímo v prohlížeči, kde vidím třeba `margin` nebo `padding` a jsem tak schopen pěkně upravit danný prvek, který mi nějak dělá potíže

**Rozdělení na části**
* dělit nějaký box na části jde více způsoby. Aktuálně to zkouším přes `grid` a vypadá to fajn. Je možné i nastavit procenta pro ty jednotlivé části, což se hodí :D
